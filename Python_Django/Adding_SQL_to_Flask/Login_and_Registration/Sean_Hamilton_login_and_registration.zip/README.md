#
This is a simple login and registration form using mySQL , flask, bcrypt, regex, all done using python programming language in addition to necessary HTML.