from flask import Flask, request, redirect, render_template, session, flash
import re
from mysqlconnection import MySQLConnector
app = Flask(__name__)
app.secret_key='thisisasecret'
mysql = MySQLConnector(app, 'emailvalidation')
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
@app.route('/')
def index():
	# emails = mysql.query_db("SELECT * FROM emails")
	# print emails
	return render_template('index.html')
@app.route('/success', methods=['POST'])
def emailss():
	# EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
	# if len(request.form['email']) < 1:
	# 	flash("Email cannot be blank!")
	# if not EMAIL_REGEX.match(request.form['email']):
	# 	flash("Invalid Email Address!")
	# else: 
	# 	flash("Success!")
	# return redirect('/')

	counter = 0
	emails = mysql.query_db("SELECT email FROM emails")
	print emails[0]['email']
	useremail = request.form['email']
	print useremail
	query = "INSERT INTO emails (email) VALUES (:email);"
	for x in emails:
		if(x['email'] == useremail):
			flash("E-mail already exists!")
			return redirect('/')
		if len(request.form['email']) < 1:
			flash('Email Cannot be Blank!')
			return redirect('/')
		elif not EMAIL_REGEX.match(request.form['email']):
			flash("Invalid Email Address!")
			return redirect('/')
		else: 
			counter = counter + 1
			# flash('Success!')
			# return redirect('/')
		# else:
		# 	mysql.query_db(query, request.form)	
		# 	return redirect('/success')
	if(counter > 0):
		mysql.query_db(query, request.form)
		return render_template('success.html', useremail=useremail, emails=emails)
# @app.route('/success')
# def success():	
# 	emailsz = mysql.query_db("SELECT email FROM emails")
# 	print emailsz
# 	# useremail = request.form['email']
# 	# emails = mysql.query_db("SELECT * FROM emails")
# 	# query = "INSERT INTO emails (email) VALUES (:email);"
# 	# print useremail
# 	# query = "INSERT INTO email (email) VALUES (:email);"
# 	# for x in range(len(emails)):
# 	# 	if(emails[x] == useremail):
# 	# 		flash("E-mail already exists!")
# 	# 		return redirect('/', useremail=useremail, query=query)
		
# 	# 	else:
# 	# 		mysql.query_db(query, request.form)	
# 	# 		return redirect('/success', useremail=useremail, query=query)

# 	return render_template('success.html', emailsz = emailsz)
			
	




app.run(debug=True)