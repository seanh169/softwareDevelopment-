from flask import Flask, request, redirect, render_template, session, flash

from mysqlconnection import MySQLConnector
app = Flask(__name__)
mysql = MySQLConnector(app, 'friendsdb')
@app.route('/')
def index():
	friends = mysql.query_db("SELECT * FROM friends")
	return render_template('index.html', friends=friends)
@app.route('/users', methods=['POST'])
def user():
	query = "INSERT INTO friends (first_name, age, created_at) VALUES (:name, :age, :friendsince);"
	mysql.query_db(query, request.form)
	return redirect("/")

app.run(debug=True)