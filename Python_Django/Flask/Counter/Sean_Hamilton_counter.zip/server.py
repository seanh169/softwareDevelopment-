from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key="hello"
app.count = 0




@app.route('/')
def index():
  	if session['count'] == 0:
  		session['count'] = 0
  	session['count'] += 1
  	return render_template("index.html", count=session['count'])
  	# session['count'] += 1
  	

# this route will handle our form submission
# notice how we defined which HTTP methods are allowed by this route

@app.route('/addcount', methods=['POST'])
def addcount():
	session['count'] += 1
	return redirect('/')
@app.route('/subtract', methods=['POST'])
def clear():
	session['count'] = 0
	return redirect('/')

app.run(debug=True)
