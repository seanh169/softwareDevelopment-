from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
# our index route will handle rendering our form
@app.route('/')
def index():
  return render_template("index.html")
# this route will handle our form submission
# notice how we defined which HTTP methods are allowed by this route
@app.route('/ninja')
def ninjas():
	return render_template("ninjas.html")

@app.route('/purple')
def purple():
	
	return render_template("purple.html")
@app.route('/blue')
def blue():
	return render_template("blue.html")
@app.route('/orange')
def orange():
	return render_template("orange.html")
@app.route('/red')
def red():
	return render_template("red.html")
# @app.errorhandler(404)
# def page_not_found():
# 	return render_template("404.html")
# @app.route('/404')
# def redirects()
# 	allowed_routes = ['/', '/ninja', '/purple', '/blue', '/orange', '/red']
# 		if request.endpoint not in allowed_routes:
# 			return redirect('/404')


app.run(debug=True)