from flask import Flask, render_template, request, redirect
app = Flask(__name__)
# our index route will handle rendering our form
@app.route('/')
def index():
  return render_template("index.html")
# this route will handle our form submission
# notice how we defined which HTTP methods are allowed by this route
@app.route('/results', methods=["POST"])

def printname():
	name = request.form['name']
	dojo = request.form['dojo']
	language = request.form['language']
	description = request.form['textarea']
	return render_template('results.html', name = name, dojo = dojo, language = language, description = description)
	return redirect('/results')
	# print name

app.run(debug=True)