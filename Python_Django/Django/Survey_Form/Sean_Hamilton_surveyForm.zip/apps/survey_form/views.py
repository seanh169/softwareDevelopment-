from django.shortcuts import render, redirect

# Create your views here.
def index(request):
	return render(request, 'survey_form/index.html')
def process(request):

	request.session['name'] = request.POST['name']
	request.session['location'] = request.POST['locations']
	request.session['languages'] = request.POST['languages']
	request.session['comment'] = request.POST['comment']
	# dicti = {
	# 'name': request.POST['name'],
	# 'location': request.POST['locations'],
	# 'language': request.POST['languages'],
	# 'comment': request.POST['comment']


	# }
	return redirect('/anotheroute')
def anotheroute(request):
	return render(request, 'survey_form/results.html')