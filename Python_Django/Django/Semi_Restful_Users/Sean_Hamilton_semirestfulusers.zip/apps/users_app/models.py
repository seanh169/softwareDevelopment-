from __future__ import unicode_literals

from django.db import models
from django.contrib import messages

# Create your models here.
class BlogManager(models.Manager):
	def basic_validator(self, postData):
		errors = {}
		if len(postData['firstname']) < 1:
			errors['name'] = 'First name hasto be at least one character'
		if len(postData['lastname']) < 1:
			errors['lastname'] = 'Last name hasto be at least one character'
		if len(postData['emailaddress']) < 1:
			errors['email'] = 'Email Address hasto be at least one character'
		# if len(postData['newfirstname']) < 1:
		# 	errors['newfirstname'] = 'First name hasto be at least one character'
		# if len(postData['newlastname']) < 1:
		# 	errors['newlastname'] = 'Last name hasto be at least one character'	
		# if len(postData['newemail']) < 1:
		# 	errors['newemail'] = 'Email address hasto be at least one character'	










		return errors





class user(models.Model):
	first_name = models.CharField(max_length=255)
	last_name = models.CharField(max_length=255)
	email = models.CharField(max_length=255)
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)
	objects = BlogManager()
