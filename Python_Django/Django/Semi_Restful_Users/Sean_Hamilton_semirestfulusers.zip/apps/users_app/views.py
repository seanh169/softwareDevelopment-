from django.shortcuts import render, redirect, HttpResponse
from models import *
from django.contrib import messages

# Create your views here.
def index(request):
	dicti = {
		'users': user.objects.all(),
	}
	return render(request, 'users_app/index.html', dicti)
def show(request, id):
	print id
	xdicti = {
		'shownuser': user.objects.get(id=id),
	}
	return render(request, 'users_app/show.html', xdicti )
def edit(request, id):
	print id
	
	xdictis = {
		'shownuser': user.objects.get(id=id),
	}


	return render(request, 'users_app/edit.html', xdictis)
def updateuser(request, id):
	errors = user.objects.basic_validator(request.POST)
	if len(errors):
		for tag, error in errors.iteritems():
			messages.error(request, error, extra_tags=tag)
			print errors['name']
		return redirect('/users_app/' +id + '/edit', error=errors)
		
	else:

		xdictis = {
			'shownuser': user.objects.get(id=id),
		}	
		theuser = user.objects.get(id=id)

		theuser.first_name = request.POST['firstname']
		theuser.last_name = request.POST['lastname']
		theuser.email=request.POST['emailaddress']
		theuser.save()

		return redirect('/users_app/' +id + '/edit', xdictis)
def new(request):
	
	
	


	return render(request, 'users_app/new.html')
def newuser(request):
	# errors = user.objects.basic_validator(request.POST)
	# if len(errors):
	# 	for tag, error in errors.iteritems():
	# 		messages.error(request, error, extra_tags=tag)
	# 		print errors['name']
	# xdictis = {
	# 	'shownuser': user.objects.get(id=id),
	# }
	theuserz = user.objects.create(first_name = request.POST['newfirstname'], last_name=request.POST['newlastname'], email=request.POST['newemail'])
	
	theuserz.save()

	return redirect('/users_app/new')
def delete(request, id):
	xdictis = {
		'shownuser': user.objects.get(id=id),
	}
	userd= user.objects.get(id=id)
	userd.delete()
	##do no save deletes


	return redirect('/', xdictis)












