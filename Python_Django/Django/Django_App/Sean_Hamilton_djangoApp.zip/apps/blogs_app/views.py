# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, HttpResponse, redirect

# Create your views here.
def index(request):
	display = "placeholder to later display all the list of blogs"
	return HttpResponse(display)

def new(request):
	new = 'placeholder to display a new form to create a new blog'
	return HttpResponse(new)
def create(request):
	return redirect('/')

def show(request, number):
	show = 'placeholder to display blog {}'.format(number)
	return HttpResponse(show)
def edit(request, number):
	edit = 'placeholder to edit blog {}'.format(number)
	return HttpResponse(edit)
def destroy(request, number):
	return redirect('/')
