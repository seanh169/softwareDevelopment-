from django.shortcuts import render, redirect, HttpResponse
import random
from time import gmtime, strftime
# Create your views here.
def index(request):
	
	if 'gold' not in request.session:
		request.session['gold'] = 0
	# if 'textadd' not in request.session:
	# 	request.session['textadd'] = 'Earned' + str(request.session["gold"]) + 'golds from the farm!'
	# 	request.session['textminus'] = 'Earned a caino and lost ' + str(request.session['gold']) + 'golds...Ouch...'
	# 	request.session['time'] = strftime('%b %d,%Y %I:%M %p', gmtime())
	if 'lists' not in request.session:
		request.session['lists'] = []
	if request.session['gold'] < 0:
		request.session['gold'] = 0
	return render(request, 'ninja_gold/index.html')
def process_money(request):
	
	if 'hiddens' in request.POST:
		if request.POST['hiddens'] == 'farm':
			farmz = random.randint(10, 20)
			request.session['gold']= request.session['gold'] + farmz
			request.session['lists'].append(['Earned ' + str(farmz) +  ' golds from the farm!' + strftime('%b %d,%Y %I:%M %p', gmtime()), 'green']) 
			
		if request.POST['hiddens'] == 'cave':
			cavez = random.randint(5, 10)
			request.session['gold'] = request.session['gold'] + cavez
			request.session['lists'].append(['Earned ' + str(cavez) + ' golds from the farm!' + strftime('%b %d,%Y %I:%M %p', gmtime()), 'green'])
			
		if request.POST['hiddens'] == 'house':
			houz = random.randint(2, 5)
			request.session['gold'] = request.session['gold'] + houz
			request.session['lists'].append(['Earned ' + str(houz) + ' golds from the farm!' + strftime('%b %d,%Y %I:%M %p', gmtime()), "green"]) 

		if request.POST['hiddens'] == 'casino':
			sean = random.randint(-50, 50)
			if sean < 0:
				request.session['fontcolor'] = 'red'
				request.session['lists'].append(['Earned a casino and lost ' + str(sean) + ' golds...Ouch...' + strftime('%b %d,%Y %I:%M %p', gmtime()), 'red'])
			else:
				request.session['fontcolor'] = 'green'
				request.session['lists'].append(['Earned ' + str(sean) + ' golds from the farm!' + strftime('%b %d,%Y %I:%M %p', gmtime()), 'green'])
			request.session['gold'] = request.session['gold'] + sean
	
		return redirect('/')
