from django.shortcuts import render, redirect, HttpResponse
from time import gmtime, strftime
# Create your views here.
def index(request):
	return render(request, 'session_words/index.html')

def add_word(request):
	if "lists" not in request.session:
		request.session['lists'] = []
	request.session['word'] = request.POST['word']
	if 'word' in request.session:
		request.session['time'] = strftime('%b %d,%Y %I:%M %p', gmtime())
		timez = request.session['time']	
	request.session['color'] = request.POST['color']
	bold = ""
	if 'bigfont' in request.POST:
		bold = "bold"
	
	dicti = {
		'whatever': request.POST['word'],
		'colorman': request.POST['color'],
		'bold': bold,
		'time': timez,

	}
	if request.session.modified == True:
		request.session['lists'].append(dict(dicti))
	# currentword = request.session['word']
	# currentcolor = request.session['color']
	
	# print lists[0]['whatever']
	return redirect('/', dicti)
def clear_word(request):
	request.session.clear()
	return redirect('/')