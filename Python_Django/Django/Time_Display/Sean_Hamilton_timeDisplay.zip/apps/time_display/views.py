from django.shortcuts import render, HttpResponse, redirect
from time import gmtime, strftime
import datetime

# Create your views here.
def index(request):
	now = datetime.datetime.now().strftime('%c')
	value = {
	'now':now,
	}
	return render(request, 'time_display/index.html', value)
def time_display(request):
	now = datetime.datetime.now().strftime('%c')
	return redirect('/', now)