# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models
import re
from datetime import datetime
import bcrypt

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9+-_.]+@[a-zA-Z0-9+-_.]+\.[a-zA-Z]+$')

class UserManager(models.Manager):
    def register(self, post_data):

        errors = []
        
        if len(post_data["first"]) < 1:
            errors.append("First name is required")
        elif len(post_data["first"]) < 2:
            errors.append("First name must be at least 2 characters long")

        if len(post_data["last"]) < 1:
            errors.append("Last name is required")
        elif len(post_data["last"]) < 2:
            errors.append("Last name must be at least 2 characters long")

        if len(post_data["email"]) < 1:
            errors.append("Email is required")
        elif not EMAIL_REGEX.match(post_data["email"]):
            errors.append("Invalid email")
        else:
            list_of_users_matching_email = User.objects.filter(email=post_data["email"].lower())
            if len(list_of_users_matching_email) > 0:
                response["errors"].append("Email already exists")

        if len(post_data["password"]) < 1:
            errors.append("Password is required")
        elif len(post_data["password"]) < 8:
            errors.append("Password must be 8 characters or more")

        if len(post_data["confirm"]) < 1:
            errors.append("Confirm password is required")
        elif post_data["password"] != post_data["confirm"]:
            errors.append("Confirm password must match Password")

        if len(post_data["date_of_birth"]) < 1:
            errors.append("Date of Birth is required")
        else:
            dob = datetime.strptime(post_data["date_of_birth"], "%Y-%m-%d")
            if dob > datetime.now():
                errors.append("Date of Birth must be in the past")

        if len(errors) > 0:
            return (False, errors)
        else:
            user = User.objects.create(
                first_name=post_data["first"], 
                last_name=post_data["last"], 
                email=post_data["email"].lower(), 
                password=bcrypt.hashpw(post_data["password"].encode(), bcrypt.gensalt()), 
                date_of_birth=dob
            )
            return (True, user)

    def login(self, post_data):
        
        response = {
            "errors": [],
            "is_valid": True,
            "user": None
        }

        if len(post_data["email"]) < 1:
            response["errors"].append("Email is required")
        elif not EMAIL_REGEX.match(post_data["email"]):
            response["errors"].append("Invalid email")
        else:
            list_of_users_matching_email = User.objects.filter(email=post_data["email"].lower())
            if len(list_of_users_matching_email) < 1:
                response["errors"].append("Email does not exist")

        if len(post_data["password"]) < 1:
            response["errors"].append("Password is required")
        elif len(post_data["password"]) < 8:
            response["errors"].append("Password must be 8 characters or more")

        if len(response["errors"]) < 1:
            user = list_of_users_matching_email[0]
            if bcrypt.checkpw(post_data["password"].encode(), user.password.encode()):
                response["user"] = user
            else:
                response["errors"].append("Password is incorrect")

        if len(response["errors"]) > 0:
            response["is_valid"] = False

        return response

class User(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    date_of_birth = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UserManager()