from __future__ import unicode_literals
from django.shortcuts import render, redirect
from .models import User
from django.contrib import messages

def index(request):
    request.session.clear()
    return render(request, "user_login/index.html")

def register(request):
    
    whatever_register_returned = User.objects.register(request.POST)
    if whatever_register_returned[0]:
        request.session["user_id"] = whatever_register_returned[1].id
        messages.add_message(request, messages.SUCCESS, 'You successfully registered, good job!')
        return redirect("/success")
    else:
        for error in whatever_register_returned[1]:
            messages.add_message(request, messages.ERROR, error)
    return redirect("/")

def login(request):
    user = User.objects.login(request.POST)
    
    
    if user["is_valid"]:
    	
        request.session["user_id"] = user["user"].id
        
        messages.add_message(request, messages.SUCCESS, 'You successfully logged in, good job!')
        return redirect("/success" , user)
    else:
        for error in user["errors"]:
            messages.add_message(request, messages.ERROR, error)
    return redirect("/")

def logout(request):
    request.session.clear()
    messages.add_message(request, messages.SUCCESS, "You have just logged out, goodbye!")
    return redirect("/")
def success(request):
	data = {
		"user": User.objects.get(id=request.session["user_id"]),
		
	}

	return render(request, 'user_login/success.html', data)