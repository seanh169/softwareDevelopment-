
public interface CalculatorInterface {
	void preformOperation();
	void getResults();
	void setOperandOne(int number);
	void setOperation(String operator);
	void setOperandTwo(int numberz);
}
