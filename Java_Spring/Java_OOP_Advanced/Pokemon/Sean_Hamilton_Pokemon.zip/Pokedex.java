public class Pokedex extends AbstractPokemon {
    public void pokemonInfo(Pokemon pokemon){
        System.out.println(pokemon.getHealth() + pokemon.getName() + pokemon.getType());
    }


}
