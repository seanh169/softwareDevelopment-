import java.util.Random;

public class BankAccount {
    private static int counter;
    private String account_number;
    private static Double checking_balance;
    private static Double savings_balance;
    private static Double totalSavings;
    private static Random rand       = new Random();

    public BankAccount(Double checkings, Double savings) {
        account_number = randomAccount();
        counter++;
        checking_balance = checkings;
        savings_balance = savings;
        this.totalSavings =  checking_balance+ savings_balance;

    }
        public static int numberOfAccounts () {
            return counter;
        }
        public static Double moneyStored () {
            return checking_balance + savings_balance;
        }
        private static String randomAccount(){
            return Integer.toString(rand.nextInt(1000000000)+1000000000);
    }
        public Double getCheckingBalance(){
            return checking_balance;
        }
        public Double setCheckingBalance(Double checkings){
            checking_balance = checking_balance + checkings;
            return checking_balance;
        }
        public Double getSavingsBalance(){
            return savings_balance;
        }
        public Double setSavingsBalance(Double savings){
            savings_balance = savings_balance + savings;
            return savings_balance;
        }
        public void depositChecking(Double amount){
            this.checking_balance= this.checking_balance+ (amount);
            this.totalSavings =  checking_balance+ savings_balance;
        }
        public void depositSavings(Double amountz){
            this.savings_balance = this.savings_balance + amountz;
            this.totalSavings =  checking_balance+ savings_balance;
        }
        public void withdrawSavings(Double amountzz) {
            if (savings_balance > amountzz) {
                setSavingsBalance(this.getSavingsBalance()-amountzz);
                this.totalSavings =  checking_balance+ savings_balance;
            }
        }
        public void withdrawCheckings(Double amountzzz) {
        if (savings_balance > amountzzz) {
            setCheckingBalance(this.getCheckingBalance()-amountzzz);
            this.totalSavings =  checking_balance+ savings_balance;
        }
        }
        public void printOutBalances(){
            System.out.println("Savings balance is " + this.savings_balance);
            System.out.println("Checkings balance is " +checking_balance);
            System.out.println("TOTAL balance is " + totalSavings);

            }
        public static void main(String[] args){
        BankAccount seansaccount = new BankAccount(12112.0, 34566.0);
        seansaccount.depositChecking(500.0);
        seansaccount.depositChecking(200.0);

        seansaccount.printOutBalances();

        }
    }
