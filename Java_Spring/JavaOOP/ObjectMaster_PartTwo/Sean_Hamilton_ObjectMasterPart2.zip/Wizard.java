public class Wizard extends Human {
    public Wizard(){
        setHealthLevel(50);
        setIntelligenceLevel(8);

    }
    public void heal(Human ally){
        ally.setHealthLevel(ally.getHealthlevel()+this.getintelligencelevel());

    }
    public void fireball(Human enemy){
        enemy.setHealthLevel(enemy.getHealthlevel()-(this.getintelligencelevel() * 3));
    }
}
