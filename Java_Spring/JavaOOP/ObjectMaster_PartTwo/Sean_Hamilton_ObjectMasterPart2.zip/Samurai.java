public class Samurai extends Human {
    private static int counter;
    public Samurai(){
        setHealthLevel(200);
        counter++;
    }
    public void deathBlow(Human enemy){
        enemy.setHealthLevel(0);
        enemy.setHealthLevel(enemy.getHealthlevel()/2);
    }
    public void meditate(){
        this.setHealthLevel(this.getHealthlevel()+(this.getHealthlevel()/2));
    }
    public int howMany() {
        System.out.println(counter);
        return counter;
    }
}
