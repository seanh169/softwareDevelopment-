public class HumanTest {
    public static void main(String[] args){
        Human newhuman = new Human();
        Human newesthuman = new Human();
        System.out.println(newesthuman.getHealthlevel());
        newhuman.attack(newesthuman);
        System.out.println(newesthuman.getHealthlevel());
        newesthuman.attack(newesthuman);
        newesthuman.attack(newhuman);
        System.out.println(newhuman.getHealthlevel());
        System.out.println(newesthuman.getHealthlevel());
        Ninja newninja = new Ninja();
        Wizard newwizard = new Wizard();
        Samurai newsamurai = new Samurai();
        newsamurai.meditate();
        System.out.println(newsamurai.getHealthlevel());
        newwizard.fireball(newninja);
        System.out.println(newninja.getHealthlevel());
        newwizard.heal(newninja);
        System.out.println((newninja.getHealthlevel()));
        newwizard.heal(newninja);
        System.out.println((newninja.getHealthlevel()));


    }
}
