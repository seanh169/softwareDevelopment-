public class Ninja extends Human {
    public Ninja() {
        setStealthLevel(10);
    }
    public void steal(Human enemy) {
       enemy.setHealthLevel(enemy.getHealthlevel() - this.getStealthlevel());
        }
    public void runaway() {
        this.setHealthLevel(this.getHealthlevel()-10);
    }
}

