public class DragonTest {
    public static void main(String[] args){
        Dragon dragonz = new Dragon();
        dragonz.displayEnergy();
        dragonz.fly();
        dragonz.eatHumans();
        dragonz.attackTown();
        dragonz.displayEnergy();

    }
}
