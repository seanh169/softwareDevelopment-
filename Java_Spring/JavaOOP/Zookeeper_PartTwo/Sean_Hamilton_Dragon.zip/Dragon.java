public class Dragon {
    private int energyLevel = 300;


    public void setEnergyLevel(int energyLevel){
        this.energyLevel = energyLevel;
    }
    public int getEnergyLevel(){
        return energyLevel;
    }
    public int displayEnergy(){
        System.out.println(energyLevel);
        return energyLevel;
    }
    public void fly(){
        System.out.println("Dragon Sound");
        setEnergyLevel(this.getEnergyLevel()- 50);
    }
    public void eatHumans(){
        System.out.println("Eat Humans Sound");
        setEnergyLevel(this.getEnergyLevel()+25);
    }
    public void attackTown(){
        System.out.println("Town attack sound");
        setEnergyLevel(this.getEnergyLevel()-100);
    }

}
