public class ProjectTest {
    public static void main(String[] args){
        Project dada = new Project("sean");
        Project lala = new Project("John", "This is Johns description");
//        dada.getName();
        dada.setDescription("This is my description");
        System.out.println(dada.getName());
        System.out.println(dada.getDescription());
        System.out.println(lala.getName());
        System.out.println("hello " + lala.getDescription());

    }


}
