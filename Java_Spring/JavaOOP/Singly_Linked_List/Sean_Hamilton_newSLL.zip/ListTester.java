

public class ListTester {
    public static void main(String[] args){
        SinglyLinkedList newsll = new SinglyLinkedList();
        newsll.add(5);
        newsll.add(10);
        newsll.add(15);
        newsll.remove();
        newsll.remove();
        newsll.add(55);
        newsll.printValues();
    }
}
