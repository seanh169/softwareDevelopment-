public class Node {
    public int value;
    public Node next;
public Node(int valueParam){
    this.value = valueParam;
    this.next = null;
}




}