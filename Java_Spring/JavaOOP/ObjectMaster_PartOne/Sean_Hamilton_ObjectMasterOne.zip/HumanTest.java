public class HumanTest {
    public static void main(String[] args){
        Human newhuman = new Human();
        Human newesthuman = new Human();
        System.out.println(newesthuman.getHealthlevel());
        newhuman.attack(newesthuman);
        System.out.println(newesthuman.getHealthlevel());
        newesthuman.attack(newesthuman);
        newesthuman.attack(newhuman);
        System.out.println(newhuman.getHealthlevel());
        System.out.println(newesthuman.getHealthlevel());

    }
}
