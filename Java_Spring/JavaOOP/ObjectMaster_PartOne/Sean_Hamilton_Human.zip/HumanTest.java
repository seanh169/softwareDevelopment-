public class HumanTest {
    public static void main(String[] args){
        Human newhuman = new Human();
        newhuman.attack();
        newhuman.getHealthlevel();
    }
}
