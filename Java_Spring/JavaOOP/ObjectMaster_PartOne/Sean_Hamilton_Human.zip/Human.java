public class Human {
    private int stealth = 3;
    private int strength = 3;
    private int intelligence = 3;
    private int health = 100;

    public void setStealthLevel(int stealthLevel){
        this.stealth = stealthLevel;
    }
    public int getStealthlevel(){
        return stealth;
    }
    public void setStrengthLevel(int strengthLevel){
        this.strength = strengthLevel;
    }
    public int getStrengthlevel(){
        return strength;
    }
    public void setIntelligenceLevel(int intelligenceLevel){
        this.intelligence = intelligenceLevel;
    }
    public int getintelligencelevel(){
        return intelligence;
    }
    public void setHealthLevel(int healthLevel){
        this.health = healthLevel;
    }
    public int getHealthlevel(){
        System.out.println(health);
        return health;
    }

    public void attack(){
        System.out.println("Attacking Human");
        setHealthLevel(this.getHealthlevel()- this.strength);
    }
}

