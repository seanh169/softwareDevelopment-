public class GorillaTest {
    public static void main(String[] args){
        Gorilla gorillaz = new Gorilla();
        gorillaz.displayEnergy();
        gorillaz.eatBananas();
        gorillaz.climb();
        gorillaz.throwSomething();
    }
}
