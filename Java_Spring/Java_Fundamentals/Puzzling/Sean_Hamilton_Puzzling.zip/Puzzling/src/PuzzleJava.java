import java.sql.Connection;
import java.util.ArrayList;
import java.util.Random;
import java.util.Collections;


public class PuzzleJava {
    public static void GreaterthanArray(){
        int sum = 0;
        int[] arr = {3,5,1,2,7,9,8,13,25,32};
        ArrayList<Integer> arrList = new ArrayList<>();
        for(int i = 0; i < arr.length; i++){
            if(arr[i] > 10) {
                arrList.add(arr[i]);
            }
            sum = sum + i;

        }
        System.out.println("Sum = " + sum);
        System.out.println(arrList);
    }
    public static void ShuffleArray() {
        ArrayList<String> arrList = new ArrayList<>();
        String[] arr = {"Nancy", "Jin", "Fujibayahsi", "Momochi", "Ishikawa"};
        for(int i = 0; i < arr.length; i++) {
            if (arr[i].length() > 5) {
                arrList.add(arr[i]);
            }

        }
        Collections.shuffle(arrList);
        System.out.println(arrList);
    }
    public static void AlphabetArray() {
        ArrayList<String> arrList = new ArrayList<>();
        String[] arr = {"a", "b", "c", "d", "e", "f", "g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
        for(int i = 0; i < arr.length; i++){
            arrList.add(arr[i]);
            Collections.shuffle(arrList);


        }
        System.out.println(arrList);
        if(arrList.get(0) == "a" || arrList.get(0) == "e" || arrList.get(0) == "i" || arrList.get(0) == "o" || arrList.get(0) == "u"){
            System.out.println("hello");
        }
        System.out.println(arrList.get(arrList.size()-1));
        System.out.println(arrList.get(0));
    }
    public static void randomnumberz() {
        ArrayList<Integer> arrList = new ArrayList<>();
        Random rand = new Random();
//        int n = rand.nextInt(100-55)+ 55;
        for(int i = 0; i < 10;i++ ){
            arrList.add(rand.nextInt(100-55)+55);
        }
        System.out.println(arrList);
        System.out.println(Collections.min(arrList));
    }
    public static void randomnumberz2() {
        ArrayList<Integer> arrList = new ArrayList<>();
        Random rand = new Random();
        for(int i = 0; i < 10;i++ ){
            arrList.add(rand.nextInt(100-55)+55);
        }

        Collections.sort(arrList);
        System.out.println(arrList);
        System.out.println(Collections.min(arrList));
        System.out.println(Collections.max(arrList));
    }
    public static void randomstring() {
        String alphabet = "abcdefghijklmnopqrstuvwxyz";
        int n = alphabet.length();
        Random r = new Random();
        for (int i = 0; i < 5; i++){
            System.out.print(alphabet.charAt(r.nextInt(n)));
        }
    }
    public static void  randStrArr(){
        String[] arr = new String[10];

        for(int i=0;i<arr.length;i++){
            arr[i] = randomstring();
        }
        return arr;
    }
    public static void main(String[] args){
//        PuzzleJava.GreaterthanArray();
//        PuzzleJava.ShuffleArray();
//        PuzzleJava.AlphabetArray();
//        PuzzleJava.randomnumberz2();
//        PuzzleJava.randomstring();
            PuzzleJava.finalrandom();
    }
}
