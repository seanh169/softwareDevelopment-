package com.example.helloworld;

public class jplc {
    public static void main(String[] args) {
        int my_age = 31;
        System.out.println("My Name is Sean Hamilton");
    System.out.println("I am  " + my_age + " years old");
    System.out.println("My hometown is Columbia, MD");
    }
}
