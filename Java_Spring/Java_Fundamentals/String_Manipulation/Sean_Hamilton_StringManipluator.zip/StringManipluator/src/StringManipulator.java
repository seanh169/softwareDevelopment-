public class StringManipulator {

    public static void main(String[] args){
    StringManipulator.getIndexOrNull("hello", "o");
    }

    public static void trimAndConcat(String one, String two) {
        String onez = one.concat(two);
        System.out.println(onez);
    }

    public static void getIndexOrNull(String one, char two) {
        String letter = one;
        int a = letter.indexOf(two);
        System.out.println(a);
    }

    public static void getIndexOrNull(String one, String two) {
        String letterz = one;
        int b = letterz.indexOf(two);
        System.out.println(b);
    }

//    public static void concatSubstring(String one, int two, int three, String four) {
//        String word = one;
//        int twoz = two;
//        int threez = three;
//        String fourz = four;
//
//    }

}