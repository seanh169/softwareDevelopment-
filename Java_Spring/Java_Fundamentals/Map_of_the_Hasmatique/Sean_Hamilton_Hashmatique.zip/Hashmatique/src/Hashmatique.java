import java.util.HashMap;



public class Hashmatique {
    public static void main(String[] args) {


        HashMap<String, String> trackList = new HashMap<>();
        trackList.put("1", "SongOne");
        trackList.put("2", "SongTwo");
        trackList.put("3", "SongThree");
        trackList.put("4", "SongFour");
        trackList.put("5", "SongFive");
        String name = trackList.get("1");
        System.out.println(trackList);
        System.out.println(name);

        for (HashMap.Entry<String, String> e : trackList.entrySet()) {
            System.out.println("Track: " + e.getKey() + " Lyrics: " + e.getValue());
    }


    }
}