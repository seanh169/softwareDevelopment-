package com.sean.DojoNinjas.repositories;

import org.springframework.data.repository.CrudRepository;

import com.sean.DojoNinjas.models.Dojo;


public interface DojoRepo extends CrudRepository<Dojo, Long> {

}
