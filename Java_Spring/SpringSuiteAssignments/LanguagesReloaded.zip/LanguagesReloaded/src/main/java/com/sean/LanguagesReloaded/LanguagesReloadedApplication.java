package com.sean.LanguagesReloaded;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LanguagesReloadedApplication {

	public static void main(String[] args) {
		SpringApplication.run(LanguagesReloadedApplication.class, args);
	}
}
