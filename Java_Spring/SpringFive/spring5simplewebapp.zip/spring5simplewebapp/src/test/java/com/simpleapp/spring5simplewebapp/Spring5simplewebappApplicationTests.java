package com.simpleapp.spring5simplewebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring5simplewebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
