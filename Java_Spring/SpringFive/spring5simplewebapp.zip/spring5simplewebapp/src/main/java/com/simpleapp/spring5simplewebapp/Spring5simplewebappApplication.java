package com.simpleapp.spring5simplewebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring5simplewebappApplication {

	public static void main(String[] args) {
		SpringApplication.run(Spring5simplewebappApplication.class, args);
	}

}
